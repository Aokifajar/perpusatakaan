-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 08, 2018 at 01:00 PM
-- Server version: 10.1.36-MariaDB
-- PHP Version: 7.2.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `loundry`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(30) NOT NULL,
  `nama` varchar(30) NOT NULL,
  `email` varchar(30) NOT NULL,
  `password` varchar(80) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `nama`, `email`, `password`) VALUES
(1, 'admin', 'admin@gmail.com', '21232f297a57a5a743894a0e4a801fc3');

-- --------------------------------------------------------

--
-- Table structure for table `jasa_laundry`
--

CREATE TABLE `jasa_laundry` (
  `id` int(20) NOT NULL,
  `nama` varchar(30) NOT NULL,
  `nama_laundry` varchar(30) NOT NULL,
  `alamat` varchar(100) NOT NULL,
  `tlp` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `jasa_laundry`
--

INSERT INTO `jasa_laundry` (`id`, `nama`, `nama_laundry`, `alamat`, `tlp`) VALUES
(1, 'ayat', 'laundry express', 'jl.cipocok jaya ,Kota Serang', '0878711120394'),
(2, 'Heri', 'Blue laundry', 'jl.cipocok jaya ,kota serang', '0878716087761'),
(3, 'Difa', 'Sakha Laundry', 'jl.ki uju kaujon, kota serang', '082248762020');

-- --------------------------------------------------------

--
-- Table structure for table `kiloan`
--

CREATE TABLE `kiloan` (
  `id` int(50) NOT NULL,
  `kiloan` varchar(50) NOT NULL,
  `harga` varchar(50) NOT NULL,
  `icon` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `kiloan`
--

INSERT INTO `kiloan` (`id`, `kiloan`, `harga`, `icon`) VALUES
(1, 'kiloan', '10000', 'kiloan.png');

-- --------------------------------------------------------

--
-- Table structure for table `news`
--

CREATE TABLE `news` (
  `id` int(10) NOT NULL,
  `judul` varchar(250) NOT NULL,
  `deskripsi` longtext NOT NULL,
  `images` varchar(250) NOT NULL,
  `date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `news`
--

INSERT INTO `news` (`id`, `judul`, `deskripsi`, `images`, `date`) VALUES
(1, 'laudnryku hadir di kota serang ', 'akan mempermudah warga kota serang untuk memesan laundry\r\nLaundry adalah bagian dari housekeeping yang bertanggung jawab atas pencucian semua linen, baik itu house laundry maupun guest laundry. Sekarang ini dalam menjalankan operasionalnya, laundry juga melayani pencucian dari luar hotel yang bertujuan untuk meningkatkan pendapatannya.', 'berita6.jpg', '2018-08-03'),
(2, 'laundryku hadir untuk ibu rumah tangga yang kebingungan cucian numpuk di rumah tinggal Laundryku Aja ', 'Pengertian Sejarah Menurut Para Ahli dan Secara Umum [Lengkap]\r\nPengertian Sejarah Menurut Para Ahli dan Secara Umum [Lengkap]\r\n29 April 2018 Oleh Zakky\r\n\r\nPengertian sejarah menurut para ahli – Apa yang dimaksud dengan sejarah? Pengertian sejarah secara umum adalah peristiwa yang telah terjadi di masa lalu. Arti sejarah pun memiliki makna yang luas meliputi unsur-unsur dan ciri-ciri tertentu.\r\n\r\nAdapun ruang lingkup sejarah dapat dibagi menjadi empat, yakni sejarah sebagai peristiwa, sejarah sebagai ilmu, sejarah sebagai kisah dan sejarah sebagai seni. Keempatnya memiliki definisi dan makna masing-masing yang menjadi pembahasan ilmu sejarah itu sendiri.', 'berita5.jpg', '2018-08-03'),
(3, 'laundryku pelayanan cepat,tepat dan berkualitas', 'Pengertian Sejarah Menurut Para Ahli dan Secara Umum [Lengkap]\r\nPengertian Sejarah Menurut Para Ahli dan Secara Umum [Lengkap]\r\n29 April 2018 Oleh Zakky\r\n\r\nPengertian sejarah menurut para ahli – Apa yang dimaksud dengan sejarah? Pengertian sejarah secara umum adalah peristiwa yang telah terjadi di masa lalu. Arti sejarah pun memiliki makna yang luas meliputi unsur-unsur dan ciri-ciri tertentu.\r\n\r\nAdapun ruang lingkup sejarah dapat dibagi menjadi empat, yakni sejarah sebagai peristiwa, sejarah sebagai ilmu, sejarah sebagai kisah dan sejarah sebagai seni. Keempatnya memiliki definisi dan makna masing-masing yang menjadi pembahasan ilmu sejarah itu sendiri.', 'berita3.jpg', '2018-08-03'),
(4, 'Laundryku Hadir di Zaman era digital untuk mempermudah pemesanan laundry', 'akan mempermudah warga kota serang untuk memesan laundry\r\nLaundry adalah bagian dari housekeeping yang bertanggung jawab atas pencucian semua linen, baik itu house laundry maupun guest laundry. Sekarang ini dalam menjalankan operasionalnya, laundry juga melayani pencucian dari luar hotel yang bertujuan untuk meningkatkan pendapatannya.', 'berita4.jpg', '2018-08-04');

-- --------------------------------------------------------

--
-- Table structure for table `pesanan`
--

CREATE TABLE `pesanan` (
  `id_pesanan` int(20) NOT NULL,
  `id_pelanggan` int(30) NOT NULL,
  `jasa_laundry` varchar(50) NOT NULL,
  `alamat_pesanan` varchar(90) NOT NULL,
  `catatan` varchar(100) NOT NULL,
  `tanggal_pesanan` varchar(40) NOT NULL,
  `jam_pesanan` varchar(40) NOT NULL,
  `jenis_pesanan` varchar(90) NOT NULL,
  `metode_pembayaran` varchar(50) NOT NULL,
  `total_pesanan` varchar(90) NOT NULL,
  `status` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `pesanan`
--

INSERT INTO `pesanan` (`id_pesanan`, `id_pelanggan`, `jasa_laundry`, `alamat_pesanan`, `catatan`, `tanggal_pesanan`, `jam_pesanan`, `jenis_pesanan`, `metode_pembayaran`, `total_pesanan`, `status`) VALUES
(49, 22, 'laundry express', 'jl.raya serang cipocok jaya komplek.puri hijau no 8', 'cepat yah', '2018-08-20', '1:52', 'satuan', 'tunai', '30000', 'selesai'),
(61, 22, 'laundry express', 'cipocok jaya kota serang', 'segera', '2018-10-14', '20:0', 'satuan', 'tunai', '30000', 'selesai'),
(62, 22, 'laundry express', 'dff', 'ff', '2018-11-08', '13:12', 'satuan', 'tunai', '30000', 'selesai');

-- --------------------------------------------------------

--
-- Table structure for table `rekening`
--

CREATE TABLE `rekening` (
  `id` int(50) NOT NULL,
  `nama` varchar(50) NOT NULL,
  `nama_bank` varchar(50) NOT NULL,
  `no_rekening` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `rekening`
--

INSERT INTO `rekening` (`id`, `nama`, `nama_bank`, `no_rekening`) VALUES
(1, 'oki fajar cahyadi', 'PT.BANK RAKYAT INDONESIA', '21432543645867968');

-- --------------------------------------------------------

--
-- Table structure for table `saldo`
--

CREATE TABLE `saldo` (
  `id` int(50) NOT NULL,
  `id_user` int(30) NOT NULL,
  `nama_bank` varchar(50) NOT NULL,
  `no_rekening` varchar(50) NOT NULL,
  `upload_bukti` varchar(100) NOT NULL,
  `saldo` varchar(100) NOT NULL,
  `nama_pengirim` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `saldo`
--

INSERT INTO `saldo` (`id`, `id_user`, `nama_bank`, `no_rekening`, `upload_bukti`, `saldo`, `nama_pengirim`) VALUES
(8, 22, 'BNI', '086816628282', 'img/ek4drqp97r9p442cvvwj.png', '6999', 'oko fajar cahyadi'),
(10, 22, 'mandiri', '078787887', 'img/3ucsf3jifk6ygqsb3u3t.png', '50000', 'cahyadi');

-- --------------------------------------------------------

--
-- Table structure for table `satuan`
--

CREATE TABLE `satuan` (
  `id` int(50) NOT NULL,
  `id_laundry` int(50) NOT NULL,
  `jenis_satuan` varchar(50) NOT NULL,
  `harga` varchar(50) NOT NULL,
  `icon` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `satuan`
--

INSERT INTO `satuan` (`id`, `id_laundry`, `jenis_satuan`, `harga`, `icon`) VALUES
(1, 1, 'T-Shirt', '20000', 'Tshirt.jpg'),
(2, 2, 'Blazer/Jacket', '30000', 'blazer.jpg'),
(3, 3, 'Shirt/Batik', '30000', 'shirt.png'),
(4, 1, 'Sweater', '30000', 'sweater.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(35) NOT NULL,
  `nama` varchar(100) NOT NULL,
  `email` varchar(50) NOT NULL,
  `telepon` varchar(35) NOT NULL,
  `password` varchar(100) DEFAULT NULL,
  `saldo` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `nama`, `email`, `telepon`, `password`, `saldo`) VALUES
(22, 'oki fajar cahyadi', 'oki', '087871608774', '12', '50000'),
(23, 'oki', 'oki@gmail.com', '578564474', '12', '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `jasa_laundry`
--
ALTER TABLE `jasa_laundry`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `kiloan`
--
ALTER TABLE `kiloan`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `news`
--
ALTER TABLE `news`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pesanan`
--
ALTER TABLE `pesanan`
  ADD PRIMARY KEY (`id_pesanan`);

--
-- Indexes for table `rekening`
--
ALTER TABLE `rekening`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `saldo`
--
ALTER TABLE `saldo`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `satuan`
--
ALTER TABLE `satuan`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `jasa_laundry`
--
ALTER TABLE `jasa_laundry`
  MODIFY `id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `kiloan`
--
ALTER TABLE `kiloan`
  MODIFY `id` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `news`
--
ALTER TABLE `news`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `pesanan`
--
ALTER TABLE `pesanan`
  MODIFY `id_pesanan` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=63;

--
-- AUTO_INCREMENT for table `rekening`
--
ALTER TABLE `rekening`
  MODIFY `id` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `saldo`
--
ALTER TABLE `saldo`
  MODIFY `id` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `satuan`
--
ALTER TABLE `satuan`
  MODIFY `id` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(35) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
